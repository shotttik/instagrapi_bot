#!/usr/bin/env python
# -*- coding: utf-8 -*-

LOGIN = "yourlogin"
PASSWORD = "yourpassword"
GOOGLE_DOC = "Crawling Instagram"
POSTS_SORT = "top"  # top or recent
TYPE = "location"  # hashtag or location
TARGET = (41.69, 44.80)
# TARGET = (46.22, 2.21)  # hashtag or tuple of coordinates 41.6938° N, 44.8015
# TARGET = "nba"  # hashtag or tuple of coordinates
MAX_FOLLOWERS = 15000
MIN_FOLLOWERS = 500
LIMIT = 1000
